package com.example.jj;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    EditText inputA, inputB;
    Button btnAdd, btnSub, btnMul, btnDiv;
    TextView txtResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputA = findViewById(R.id.inputA);
        inputB = findViewById(R.id.inputB);
        btnAdd = findViewById(R.id.btnAdd);
        btnSub = findViewById(R.id.btnSub);
        btnMul = findViewById(R.id.btnMul);
        btnDiv = findViewById(R.id.btnDiv);
        txtResult = findViewById(R.id.txtResult);

        btnAdd.setOnClickListener(v -> compute("add"));
        btnSub.setOnClickListener(v -> compute("sub"));
        btnMul.setOnClickListener(v -> compute("mul"));
        btnDiv.setOnClickListener(v -> compute("div"));
    }

    private void compute(String operation) {
        String aStr = inputA.getText().toString().trim();
        String bStr = inputB.getText().toString().trim();

        if (aStr.isEmpty() || bStr.isEmpty()) return;

        String result = "";
        switch (operation) {
            case "add":
                result = addBig(aStr, bStr);
                break;
            case "sub":
                result = subBig(aStr, bStr);
                break;
            case "mul":
                result = mulBig(aStr, bStr);
                break;
            case "div":
                result = divBig(aStr, bStr);
                break;
        }
        txtResult.setText(result);
    }


    private String addBig(String num1, String num2) {
        StringBuilder result = new StringBuilder();
        int i = num1.length()-1, j = num2.length()-1, carry=0;
        while(i>=0 || j>=0 || carry!=0){
            int a = i>=0 ? num1.charAt(i)-'0':0;
            int b = j>=0 ? num2.charAt(j)-'0':0;
            int sum = a+b+carry;
            result.append(sum%10);
            carry = sum/10;
            i--; j--;
        }
        return result.reverse().toString();
    }


    private String subBig(String num1, String num2){
        StringBuilder result = new StringBuilder();
        int i = num1.length()-1, j = num2.length()-1, borrow=0;
        while(i>=0){
            int a = num1.charAt(i)-'0'-borrow;
            int b = j>=0 ? num2.charAt(j)-'0' : 0;
            if(a < b){
                a +=10;
                borrow=1;
            }else borrow=0;
            result.append(a-b);
            i--; j--;
        }

        while(result.length()>1 && result.charAt(result.length()-1)=='0') result.setLength(result.length()-1);
        return result.reverse().toString();
    }


    private String mulBig(String num1, String num2){
        int n = num1.length(), m = num2.length();
        int[] res = new int[n+m];
        for(int i=n-1;i>=0;i--){
            for(int j=m-1;j>=0;j--){
                int mul = (num1.charAt(i)-'0')*(num2.charAt(j)-'0') + res[i+j+1];
                res[i+j+1] = mul%10;
                res[i+j] += mul/10;
            }
        }
        StringBuilder sb = new StringBuilder();
        for(int num: res) sb.append(num);

        while(sb.length()>1 && sb.charAt(0)=='0') sb.deleteCharAt(0);
        return sb.toString();
    }


    private String divBig(String num1, String num2){
        if(num2.equals("0")) return "تقسیم بر صفر غیرمجاز است";
        StringBuilder result = new StringBuilder();
        String temp = "";
        for(int i=0;i<num1.length();i++){
            temp += num1.charAt(i);
            int count=0;
            while(compareBig(temp,num2)>=0){
                temp = subBig(temp,num2);
                count++;
            }
            result.append(count);
        }

        while(result.length()>1 && result.charAt(0)=='0') result.deleteCharAt(0);
        return result.toString();
    }


    private int compareBig(String num1, String num2){
        if(num1.length()>num2.length()) return 1;
        if(num1.length()<num2.length()) return -1;
        for(int i=0;i<num1.length();i++){
            if(num1.charAt(i)>num2.charAt(i)) return 1;
            if(num1.charAt(i)<num2.charAt(i)) return -1;
        }
        return 0;
    }
}
